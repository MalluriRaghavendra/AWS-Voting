## Infrastructure as code 
this was done with website former2.com - service that generates various templates, i.e. cloudformation, terraform, troposphere, cdk from existing resources.
It did not work well!
this diagram shows how some links are missing

![former2](https://user-images.githubusercontent.com/4441068/216026457-656be846-1912-4112-80a4-740ce29f5a6b.png)
