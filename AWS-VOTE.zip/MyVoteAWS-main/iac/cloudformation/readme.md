## cloudformation diagram

generated from aws cloudformation service:

![myvote-cloudformation-designer](https://user-images.githubusercontent.com/4441068/216306078-7405e50c-2676-4916-8c88-ad4be0d74d63.png)
